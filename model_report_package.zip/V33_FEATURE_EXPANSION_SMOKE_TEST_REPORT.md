# v3.3 feature-expansion smoke test

This smoke test confirms that the edited app can load the compact artifacts, build the expanded feature set, run base v3/v3.2-compatible predictions, apply the v3.3 no-residual postprocessor, and export outputs.

## Summary

| Metric | Value |
|---|---:|
| Files tested | 4 |
| Rows tested | 3828 |
| Predicted units | 10217 |
| Nonzero predictions | 2015 |
| Negative allocation violations | 0 |
| Row over-DC violations | 0 |

## Added features tested

- Raw `Dc Avail` buckets: `0`, `1-25`, `26-50`, `51-100`, `101-300`, `301-600`, `601-1000`, `1001-2000`, `2000+`.
- `Proj. Demand` / `Alloc. Rec.` features: FLM-scaled gaps, agreement ratios, post-rec supply ratios, DC-after-rec, and recommendation-vs-projection flags.

## Important compatibility note

The included compact artifacts are still old-width artifacts, so the feature builder preserves the old neural-network feature width at inference. The v3.3 trainer includes the new feature columns when you retrain, so the larger model can learn them directly. The deterministic postprocessor also uses the new raw bucket and projection/recommendation features immediately.
