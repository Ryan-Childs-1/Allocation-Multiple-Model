# v3.4 Site 802 specialist smoke-test report

## What changed

v3.4 keeps the v3.3 expanded feature path and adds one compact specialist artifact:

```text
compact_artifacts/site802_specialist_model.npz
```

That file contains both the **Site 802 Allocate specialist** and the **Site 802 Review specialist**. The app routes rows as follows:

1. Run the normal v3/v3.3 split Allocate/Review model.
2. Apply the v3.3 feature-expanded no-residual layer.
3. If `Site == 802`, route the row through the Site 802 specialist for its segment.
4. Apply FLM rounding, `Dc Avail` cap, and below-FLM final-remainder handling.

The specialist model uses the original sheet fields heavily: `Alloc. Rec.`, `Proj. Demand`, `Supply`, `Dc Avail`, `FLM`, `Cost`, `Rank`, and the demand/sales fields `L30`, `D30`, `D60`, `LW`, and `TTM`.

## Smoke-test coverage

The test used the first 2,500 working-table rows from each of the 4 provided `.xlsb` workbooks.

| Coverage | Rows |
|---|---:|
| Total eligible rows | 6,918 |
| Site 802 eligible rows | 193 |
| Site 802 Allocate rows | 138 |
| Site 802 Review rows | 55 |

## Site 802 result

| Model | MAE Units | Exact Rate | False Positives | False Negatives | Pred Units | Actual Units | Unit Delta |
|---|---:|---:|---:|---:|---:|---:|---:|
| Original v3 | 3.497 | 46.6% | 92 | 0 | 899 | 224 | +675 |
| v3.4 Site 802 full-fit | 0.487 | 83.9% | 3 | 21 | 158 | 224 | -66 |
| v3.4 Site 802 leave-one-file-out | 1.280 | 72.5% | 17 | 31 | 143 | 224 | -81 |

## Interpretation

The **full-fit smoke test** shows how the packaged Site 802 specialist behaves when trained on the available Site 802 examples. The **leave-one-file-out result** is the more honest generalization check because each workbook is predicted using a Site 802 specialist trained on the other workbooks.

Use `v34_summary_metrics.csv`, `v34_file_segment_metrics.csv`, and `v34_site802_prediction_detail.csv` for detailed review.
