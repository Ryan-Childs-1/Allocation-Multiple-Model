# Allocation Split Expert v3.9 Feature-Pruned AK + Site 802

This branch starts from v3.8 AK Specialist and prunes the low-value feature behavior found in smoke testing.

## What changed

- Keeps the v3.7 Competition-Aware feature set for retraining.
- Keeps Site 802 specialist routing.
- Keeps AK Allocate specialist behavior because tested AK Allocate rescues were beneficial.
- Tightens AK Review specialist behavior by removing weak low-unit Review rescues with less than 2.5 sheet-need FLMs.
- Keeps larger AK Review rescues that showed positive target support.

## Compact artifacts

The compact artifact folder remains concise:

```text
compact_artifacts/
  model_config.json
  allocate_model.npz
  review_model.npz
  site802_specialist_model.npz
  ak_specialist_model.npz
  v39_feature_pruned_params.json
  model_report_package.zip
```

## Smoke-test result

Compared with v3.8, v3.9 slightly improved weighted MAE, exact match, Review MAE, AK Review MAE, and false positives while preserving AK Allocate and Site 802 behavior.
