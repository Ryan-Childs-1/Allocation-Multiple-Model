# v3.2 Enhanced No-Residual vs Original v3 Test Report

## Scope

This comparison used the four extracted sample CSV files from the provided allocation workbooks. The samples preserve original worksheet fields and `Final Alloc.` targets while avoiding slow repeated `.xlsb` parsing.

## What changed

- Removed residual correction entirely.
- Kept larger v3-style training architecture in the trainer.
- Kept expanded feature engineering around `L30`, `D30`, `D60`, `LW`, `TTM`, `Supply`, `Proj. Demand`, `Alloc. Rec.`, `FLM`, and `Dc Avail`.
- Tuned a small no-residual demand/supply adjustment layer.
- Strongly prioritized original worksheet features, especially `Alloc. Rec.`, `Proj. Demand`, `Supply`, `Dc Avail`, and the demand/sales columns.

## Selected parameters

```json
{
  "allocate_cap_margin_flm": 1.0,
  "review_cap_margin_flm": 1.0,
  "cap_sheet_need_mult": 1.0,
  "cap_velocity_mult": 1.05,
  "cap_consensus_max": 0.67,
  "cap_min_base_over_rec_flms": 0.0,
  "cap_reduce_to_rec_plus_flms": 1.0,
  "rescue_enabled": false,
  "review_keep_original": true
}
```

## Holdout summary

| sample_type   | model                     | segment   |   rows |   actual_units |   pred_units |   unit_delta_vs_actual |   false_positive_rows |   false_negative_rows |   over_dc_rows |   negative_rows |   mae_units |   mae_packs |   exact_units_rate |   within_1_flm_rate |   within_2_flm_rate |   large_miss_gt_2_flm_rate |
|:--------------|:--------------------------|:----------|-------:|---------------:|-------------:|-----------------------:|----------------------:|----------------------:|---------------:|----------------:|------------:|------------:|-------------------:|--------------------:|--------------------:|---------------------------:|
| holdout_test  | original_v3               | ALL       |   1828 |           5480 |         6006 |                    526 |                    84 |                    48 |              0 |               0 |    0.637856 |   0.120168  |           0.891138 |            0.991247 |            0.996171 |                 0.00382932 |
| holdout_test  | v3.2_enhanced_no_residual | ALL       |   1828 |           5480 |         4996 |                   -484 |                    49 |                   107 |              0 |               0 |    0.69256  |   0.133388  |           0.878556 |            0.991247 |            0.996171 |                 0.00382932 |
| holdout_test  | original_v3               | ALLOCATE  |   1000 |           4834 |         5487 |                    653 |                    75 |                     7 |              0 |               0 |    0.869    |   0.158     |           0.862    |            0.989    |            0.995    |                 0.005      |
| holdout_test  | v3.2_enhanced_no_residual | ALLOCATE  |   1000 |           4834 |         4475 |                   -359 |                    40 |                    66 |              0 |               0 |    0.969    |   0.182     |           0.839    |            0.989    |            0.995    |                 0.005      |
| holdout_test  | original_v3               | REVIEW    |    828 |            646 |          519 |                   -127 |                     9 |                    41 |              0 |               0 |    0.358696 |   0.0744767 |           0.926329 |            0.993961 |            0.997585 |                 0.00241546 |
| holdout_test  | v3.2_enhanced_no_residual | REVIEW    |    828 |            646 |          521 |                   -125 |                     9 |                    41 |              0 |               0 |    0.358696 |   0.0746779 |           0.926329 |            0.993961 |            0.997585 |                 0.00241546 |

## Holdout deltas

| sample_type   | segment   |   mae_units_delta_v32_minus_v3 |   exact_rate_delta |   unit_delta_abs_improvement |   false_positive_delta |   false_negative_delta |   v3_mae_units |   v32_mae_units |   v3_unit_delta |   v32_unit_delta |
|:--------------|:----------|-------------------------------:|-------------------:|-----------------------------:|-----------------------:|-----------------------:|---------------:|----------------:|----------------:|-----------------:|
| holdout_test  | ALL       |                      0.0547046 |         -0.0125821 |                           42 |                    -35 |                     59 |       0.637856 |        0.69256  |             526 |             -484 |
| holdout_test  | ALLOCATE  |                      0.1       |         -0.023     |                          294 |                    -35 |                     59 |       0.869    |        0.969    |             653 |             -359 |
| holdout_test  | REVIEW    |                      0         |          0         |                            2 |                      0 |                      0 |       0.358696 |        0.358696 |            -127 |             -125 |

## Decision

v3.2 did not improve holdout MAE, but improved total unit bias. Original v3 remains better for row-level accuracy.
