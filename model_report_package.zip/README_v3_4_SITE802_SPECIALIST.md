# Allocation Split Expert v3.4 Site 802 Specialist

Adds dedicated Site 802 specialist models for Allocate and Review rows on top of the v3.3 expanded feature path.

Compact artifact files:

```text
compact_artifacts/model_config.json
compact_artifacts/allocate_model.npz
compact_artifacts/review_model.npz
compact_artifacts/site802_specialist_model.npz
compact_artifacts/v33_no_residual_params.json
```

The specialist uses a combined single `.npz` file for both Allocate and Review Site 802 models.
